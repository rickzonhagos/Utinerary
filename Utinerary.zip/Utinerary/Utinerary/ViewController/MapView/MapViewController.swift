//
//  MapViewController.swift
//  Utinerary
//
//  Created by rickzon hagos on 22/8/15.
//  Copyright (c) 2015 RHMH. All rights reserved.
//

import UIKit

import MapKit

typealias LocationSearchCompletionBlock  =  (mapItems : [MKMapItem]?)->(Void)


class MapViewController: UIViewController{
    
    
    @IBOutlet private weak var searchBar: UISearchBar!
    @IBOutlet private  weak var mapView: MKMapView!
    
    var locationManager : LocationManager?
    
    private var searchItems : [MKMapItem]?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        locationManager = LocationManager.sharedInstance
        
        
        initMapView()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: Location Manager
    private func initMapView(){
        mapView.showsUserLocation = true
        mapView.mapType = MKMapType.Standard
        mapView.zoomEnabled = true
        mapView.scrollEnabled = true
    }
    
    // MARK: Search Bar
    func initSearchBarAndSearchController(){
        searchBar.delegate = self
        
        self.searchDisplayController?.delegate = self
    }
    
    // MARK: Button Event
    
    @IBAction private func navigationButtonEvent(sender : UIBarButtonItem){
        if let anotations = mapView.annotations {
            let anotation  = anotations[0] as? MKAnnotation
            let coordinate : CLLocationCoordinate2D = anotation!.coordinate
            let location : CLLocation = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
            
            locationManager?.startGeoCodeWithLocation(location)
        }
        
        //self.dismissViewControllerAnimated(true, completion: nil)
    }
    
}

extension MapViewController : UITableViewDelegate , UITableViewDataSource{
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let items = searchItems {
            return items.count
        }
        return 0
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var section = indexPath.section
        let row  = indexPath.row
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier:"addCategoryCell")
        cell.selectionStyle =  UITableViewCellSelectionStyle.None
        cell.backgroundColor = UIColor.clearColor()
        cell.contentView.backgroundColor = UIColor.clearColor()
        cell.textLabel?.textAlignment = NSTextAlignment.Left
        cell.textLabel?.textColor = UIColor.blackColor()
        cell.textLabel?.font = UIFont.systemFontOfSize(14.0)
        
        
        if let items = searchItems {
            let item : MKMapItem = items[row]
            cell.textLabel?.text = item.name
            
        }
        return cell
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        let row  = indexPath.row
        if let items = searchItems {
            let item : MKMapItem = items[row]
            
            let coords = item.placemark.location.coordinate
            
            let anotation : MKAnnotation = LocationManager.createMapAnotationWithTitle(item.name, coordinate: coords)
            mapView.addAnnotation(anotation)
            mapView.selectAnnotation(anotation, animated: true)
            mapView.centerCoordinate = coords
            
            self.searchDisplayController?.searchResultsTableView.hidden = true
            self.searchDisplayController?.setActive(false, animated: true)
            
        }
    }
}
extension MapViewController : UISearchDisplayDelegate{
        
}
extension MapViewController : UISearchBarDelegate{
    func searchBarShouldBeginEditing(searchBar: UISearchBar) -> Bool{
        
        mapView.removeAnnotations(mapView.annotations)
        return true
    }
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        
    }
    func searchBarShouldEndEditing(searchBar: UISearchBar) -> Bool {
        return true
    }
    func searchBarTextDidEndEditing(searchBar: UISearchBar){
        
    }
  
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        let searchString = searchBar.text
        locationManager!.startLocationSearchWithSearchString(searchString, region: mapView.region) {
            [unowned self](mapItems) -> (Void) in
            
            self.searchItems = mapItems
            self.searchDisplayController?.searchResultsTableView.reloadData()
            
        }
        
        searchBar.resignFirstResponder()
        searchBar.endEditing(true)
        
    }
    
}
extension MapViewController : MKMapViewDelegate {
    func mapView(mapView: MKMapView!, didFailToLocateUserWithError : NSError!) {
        
    }
    func mapView(mapView: MKMapView!, didUpdateUserLocation userLocation: MKUserLocation!) {
       
    }
    
    func mapViewDidFinishLoadingMap(mapView: MKMapView!) {
        
    }
    
}
